package com.hoteservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelservicesApplication.class, args);
	}

}
